function BdayApp(){
	var n1 = document.getElementById("name1").value;
	var n2 = document.getElementById("name2").value;
	var d1 = new Date(document.getElementById("bday1").value);
	var d2 = new Date(document.getElementById("bday2").value);
	var output1 = n1+" was born on "+(d1.getDate()+1)+'/'+(d1.getMonth()+1)+'/'+d1.getFullYear()+"<br>";
	var output2 = n2+" was born on "+(d2.getDate()+1)+'/'+(d2.getMonth()+1)+'/'+d2.getFullYear()+"<br>";
	var output3 = "";
	if(d1<d2){
		output3 += n1+" is older than "+ n2;
		}
	else if(d2<d1){
		output3 += n1+" is younger than "+ n2;
	}
	else{
		output3 += n1+" and "+ n2+" are the same age!";
		}
	document.getElementById("bdayOutput").innerHTML = output1+output2+output3;
	}