	
function hol(){
	
	//check whether input is valid:
	var inputValid = true;
	var inputDate = new Date(document.getElementById("holiday").value);
	var inputMonth = inputDate.getMonth();
	var inputDay = inputDate.getDate();
	var inputYear = inputDate.getFullYear();
	
	
	var checkpoint1 = new Date(2016,9,1);
	var checkpoint2 = new Date(2017,8,31);
	if(inputDate<checkpoint1||inputDate>checkpoint2){
	inputValid = false;
	}
	
	if(inputValid){
		var arr_mon = new Array(12);
		for(var i = 0; i<12;i++){
			var arr_day = new Array(31);
			
			for(var j = 0;j<31;j++){
				arr_day[j]="";
				}
			arr_mon[i] = arr_day;	
			}
			//build holiday in multiple array:
			arr_mon[8][4] = ["Labor Day","pic/labor_day.png"];
			
			for(var a =22; a<=26; a++){
				arr_mon[10][a] = ["Thanksgiving","pic/thanksgiving.jpg"];
				}
			arr_mon[11][12] = ["Legislative Day","pic/lDay.jpg"];
			arr_mon[11][16] = ["Reading Day","pic/book.jpg"];
			arr_mon[11][17] = ["Reading Day","pic/book.jpg"];
			arr_mon[9][9] = ["Fall recess","pic/fall.jpg"];
			arr_mon[11][23] = ["Twas Night","pic/twasnight.jpg"];
			arr_mon[11][24] = ["Christmas","pic/christmas.jpg"];
			for(var a =25; a<=31; a++){
				arr_mon[11][a] = ["Winter Break","pic/winter.png"];
				}
			for(var a =0; a<=21; a++){
				arr_mon[0][a] = ["Winter Break","pic/winter.png"];
				}
			arr_mon[0][15] = ["Martin Luther King, Jr. Birthday","pic/martin.jpg"];
			arr_mon[1][19] = ["Presidents' Day","pic/president.jpg"];

			for(var a =12; a<=18; a++){
				arr_mon[2][a] = ["Spring Recess","pic/spring-break.png"];
				}
			
			arr_mon[4][8] = ["Reading Day","pic/book.jpg"];
			arr_mon[4][16] = ["Commencement","pic/comm.jpg"];
			arr_mon[4][28] = ["Memorial Day","pic/m.jpg"];
			arr_mon[6][3] = ["Independence Day","pic/independent.jpg"];
			arr_mon[7][26] = ["Move in Day","pic/movein.jpg"];
			
			
			//checking for match
			var inputMonth = inputDate.getMonth();
			var inputDay = inputDate.getDate();
			if(arr_mon[inputMonth][inputDay]==""){
			alert("Empty");
			}else{
			document.getElementById("output1").innerHTML = arr_mon[inputMonth][inputDay][0];
			document.getElementById("output2").src = arr_mon[inputMonth][inputDay][1];
			
			
			/*arr_mon[0][0]="holiday";
			console.log(arr_mon[0][0]);*/
		}
	}
	else{
		alert("The input is incorrect!");
	}

	
	//construction of the array:

	
	/*//construction of the array:
	var n1 = document.getElementById("name1").value;
	var n2 = document.getElementById("name2").value;
	var d1 = new Date(document.getElementById("bday1").value);
	var d2 = new Date(document.getElementById("bday2").value);
	var output1 = n1+" was born on "+d1.getDate()+'/'+d1.getMonth()+'/'+d1.getFullYear()+"<br>";
	var output2 = n2+" was born on "+d2.getDate()+'/'+d2.getMonth()+'/'+d2.getFullYear()+"<br>";
	var output3 = "";
	if(d1<d2){
		output3 += n1+" is older than "+ n2;
		}
	else if(d2<d1){
		output3 += n1+" is younger than "+ n2;
	}
	else{
		output3 += n1+" and "+ n2+" are the same age!";
		}
	document.getElementById("bdayOutput").innerHTML = output1+output2+output3;*/
	}