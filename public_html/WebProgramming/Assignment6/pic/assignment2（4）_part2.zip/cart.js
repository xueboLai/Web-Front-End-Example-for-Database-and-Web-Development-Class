function totol12(){
	document.getElementById("sub1").value = 2;
	document.getElementById("sub2").value = 2;
	document.getElementById("total").value = 2;

}
	
/*function totol12(){
	var subtotal1 = document.getElementById("quantity1").value*document.getElementById("price1").value;
	var subtotal2 = document.getElementById("quantity2").value*document.getElementById("price2").value;
	var total1 = subtotal1+subtotal2;
	document.getElementById("sub1").value = subtotal1;
	document.getElementById("sub2").value = subtotal2;
	document.getElementById("total").value = total1;

}*/